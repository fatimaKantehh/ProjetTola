<?php
require('../includes/connection.php');
require('session.php');

if (isset($_POST['btnlogin'])) {
    $username = trim($_POST['user']);
    $password = trim($_POST['password']);

    if ($password == '') {
        ?>
        <script type="text/javascript">
            alert("Password is missing!");
            window.location = "login.php";
        </script>
        <?php
    } else {
        // Requête SQL pour récupérer l'utilisateur avec le mot de passe en texte clair
        $sql = "SELECT u.ID, e.FIRST_NAME, e.LAST_NAME, e.GENDER, e.EMAIL, e.PHONE_NUMBER, j.JOB_TITLE, l.PROVINCE, l.CITY, t.TYPE
                FROM `users` u
                JOIN `employee` e ON e.EMPLOYEE_ID = u.EMPLOYEE_ID
                JOIN `location` l ON e.LOCATION_ID = l.LOCATION_ID
                JOIN `job` j ON e.JOB_ID = j.JOB_ID
                JOIN `type` t ON t.TYPE_ID = u.TYPE_ID
                WHERE `USERNAME` = ? AND `PASSWORD` = ?";

        if ($stmt = $db->prepare($sql)) {
            // Vous devez adapter cette partie en fonction de votre structure de base de données actuelle
            // Assurez-vous que `PASSWORD` fait référence à la colonne réelle dans votre table `users`
            $stmt->bind_param("ss", $username, $password);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows > 0) {
                $found_user = $result->fetch_array(MYSQLI_ASSOC);
                $_SESSION['MEMBER_ID']  = $found_user['ID']; 
                $_SESSION['FIRST_NAME'] = $found_user['FIRST_NAME']; 
                $_SESSION['LAST_NAME']  = $found_user['LAST_NAME'];  
                $_SESSION['GENDER']     = $found_user['GENDER'];
                $_SESSION['EMAIL']      = $found_user['EMAIL'];
                $_SESSION['PHONE_NUMBER'] = $found_user['PHONE_NUMBER'];
                $_SESSION['JOB_TITLE']  = $found_user['JOB_TITLE'];
                $_SESSION['PROVINCE']   = $found_user['PROVINCE']; 
                $_SESSION['CITY']       = $found_user['CITY']; 
                $_SESSION['TYPE']       = $found_user['TYPE'];

                if ($_SESSION['TYPE'] == 'Admin') {
                    ?>
                    <script type="text/javascript">
                        alert("<?php echo $_SESSION['FIRST_NAME']; ?> Welcome!");
                        window.location = "index.php";
                    </script>
                    <?php
                } elseif ($_SESSION['TYPE'] == 'User') {
                    ?>
                    <script type="text/javascript">
                        alert("<?php echo $_SESSION['FIRST_NAME']; ?> Welcome!");
                        window.location = "index.php";
                    </script>
                    <?php
                }
            } else {
                ?>
                <script type="text/javascript">
                    alert("Username or Password Not Registered! Contact Your administrator.");
                    window.location = "login.php";
                </script>
                <?php
            }

            $stmt->close();
        } else {
            echo "Error: " . $db->error;
        }
    }       
} 
$db->close();
?>
