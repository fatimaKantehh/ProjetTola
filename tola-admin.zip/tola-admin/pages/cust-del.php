<?php
include'../includes/connection.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Assurez-vous que l'ID est un entier
    $id = intval($id);

    // Requête pour supprimer le client
    $query = "DELETE FROM customer WHERE CUST_ID = $id";
    $result = mysqli_query($db, $query);

    if ($result) {
        echo '<script type="text/javascript">
                alert("Customer deleted successfully.");
                window.location = "customer.php";
              </script>';
    } else {
        echo '<script type="text/javascript">
                alert("Error deleting customer.");
                window.location = "customer.php";
              </script>';
    }
}
?>
