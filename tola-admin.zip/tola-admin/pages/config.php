<?php 

$server = "localhost";
$user = "Oulimata";
$pass = "passer2024";
$database = "tola-admin";

$conn = mysqli_connect($server, $user, $pass, $database);

if (!$conn) {
    die("<script>alert('Connection Failed.')</script>");
}

?>