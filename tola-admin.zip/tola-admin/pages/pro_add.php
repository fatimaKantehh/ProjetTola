<?php
include '../includes/connection.php';
include '../includes/sidebar.php';

$query = 'SELECT ID, t.TYPE
          FROM users u
          JOIN type t ON t.TYPE_ID=u.TYPE_ID WHERE ID = '.$_SESSION['MEMBER_ID'];
$result = mysqli_query($db, $query) or die(mysqli_error($db));

while ($row = mysqli_fetch_assoc($result)) {
    $Aa = $row['TYPE'];

    if ($Aa == 'User') {
        echo '<script type="text/javascript">
                alert("Restricted Page! You will be redirected to POS");
                window.location = "index.php";
              </script>';
        exit();
    }
}

?>

<center>
<div class="card shadow mb-4 col-xs-12 col-md-8 border-bottom-primary">
    <div class="card-header py-3">
        <h4 class="m-2 font-weight-bold text-primary">Add Category</h4>
    </div>
    <a href="product.php?action=add" type="button" class="btn btn-primary bg-gradient-primary">Back</a>
    <div class="card-body">
        <div class="table-responsive">
            <form role="form" method="post" action="pro_transac.php?action=add">
                <div class="form-group">
                    <input class="form-control" placeholder="Category Code" name="prodcode" required>
                </div>
                <div class="form-group">
                    <input class="form-control" placeholder="Name" name="name" required>
                </div>
                <div class="form-group">
                    <textarea rows="5" cols="50" class="form-control" placeholder="Description" name="description" required></textarea>
                </div>
                <hr>
                <button type="submit" class="btn btn-success btn-block"><i class="fa fa-check fa-fw"></i>Save</button>
                <button type="reset" class="btn btn-danger btn-block"><i class="fa fa-times fa-fw"></i>Reset</button>
            </form>
        </div>
    </div>
</div>
</center>

<?php
include '../includes/footer.php';
?>
