<?php
include('../includes/connection.php');

// Récupérer les valeurs du formulaire
$zz = $_POST['id'];
$pc = $_POST['prodcode'];
$pname = $_POST['prodname'];
$desc = $_POST['description'];

// Sanitization des entrées utilisateurs
$zz = mysqli_real_escape_string($db, $zz);
$pc = mysqli_real_escape_string($db, $pc);
$pname = mysqli_real_escape_string($db, $pname);
$desc = mysqli_real_escape_string($db, $desc);

// Requête de mise à jour
$query = "UPDATE product SET NAME='$pname', DESCRIPTION='$desc' WHERE PRODUCT_CODE='$pc'";
$result = mysqli_query($db, $query);

if ($result) {
    echo '<script type="text/javascript">
            alert("You\'ve Updated the Product Successfully.");
            window.location = "product.php";
          </script>';
} else {
    echo '<script type="text/javascript">
            alert("There was an error updating the product.");
            window.location = "product.php";
          </script>';
}
?>
