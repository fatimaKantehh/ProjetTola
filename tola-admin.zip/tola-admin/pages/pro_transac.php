<?php
include '../includes/connection.php';
?>
<!-- Page Content -->
<div class="col-lg-12">
    <?php
    $pc = $_POST['prodcode'];
    $name = $_POST['name'];
    $desc = $_POST['description'];

    switch ($_GET['action']) {
        case 'add':
            $query = "INSERT INTO product (PRODUCT_CODE, NAME, DESCRIPTION)
                      VALUES ('$pc', '$name', '$desc')";
            $result = mysqli_query($db, $query);

            if ($result) {
                echo '<script type="text/javascript">
                        alert("Product successfully added.");
                        window.location = "product.php";
                      </script>';
            } else {
                echo '<script type="text/javascript">
                        alert("There was an error adding the product.");
                        window.location = "pro-add.php";
                      </script>';
            }
            break;
    }
    ?>
</div>
<?php
include '../includes/footer.php';
?>
