<?php
$servername = "localhost";
$username = "Oulimata";
$password = "passer2024";
$dbname = "tola-admin";

$db = new mysqli($servername, $username, $password, $dbname);

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}
?>
