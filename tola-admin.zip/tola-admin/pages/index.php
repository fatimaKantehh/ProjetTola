<?php
include'../includes/connection.php';

include'../includes/sidebar.php';
?><?php 

                $query = 'SELECT ID, t.TYPE
                          FROM users u
                          JOIN type t ON t.TYPE_ID=u.TYPE_ID WHERE ID = '.$_SESSION['MEMBER_ID'].'';
                $result = mysqli_query($db, $query) or die (mysqli_error($db));
      
                while ($row = mysqli_fetch_assoc($result)) {
                          $Aa = $row['TYPE'];
                   
if ($Aa=='User'){
           
             ?>    <script type="text/javascript">
                      //then it will be redirected
                      alert("Restricted Page! You will be redirected to Home");
                      window.location = "index.php";
                  </script>
             <?php   }
                         
           
}   
            ?><?php
            $images = [
              '../img/content-moderation.png',
              '../img/donnee.jpg',
              '../img/users.jpg',
              // Ajoutez d'autres éléments ici
          ];
          ?>
 
    <div class="row justify-content-center">

      <!-- Customer ROW -->
      <div class="col-md-3 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
          <div class="card-body">
            <div class="row no-gutters align-items-center">
              <div class="col mr-2">
                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Customers</div>
                <div class="h6 mb-0 font-weight-bold text-gray-800">
                  <?php 
                    $query = "SELECT COUNT(*) FROM customer";
                    $result = mysqli_query($db, $query) or die(mysqli_error($db));
                    while ($row = mysqli_fetch_array($result)) {
                      echo "$row[0]";
                    }
                  ?> Record(s)
                </div>
              </div>
              <div class="col-auto">
                <i class="fas fa-users fa-2x text-gray-300"></i>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Product ROW -->
      <div class="col-md-3 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
          <div class="card-body">
            <div class="row no-gutters align-items-center">
              <div class="col mr-2">
                <div class="text-xs font-weight-bold text-info text-uppercase mb-1">Categories</div>
                <div class="h6 mb-0 font-weight-bold text-gray-800">
                  <?php 
                    $query = "SELECT COUNT(*) FROM product";
                    $result = mysqli_query($db, $query) or die(mysqli_error($db));
                    while ($row = mysqli_fetch_array($result)) {
                      echo "$row[0]";
                    }
                  ?> Record(s)
                </div>
              </div>
              <div class="col-auto">
                <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- Registered Account ROW -->
      <div class="col-md-3 mb-4">
        <div class="card border-left-danger shadow h-100 py-2">
          <div class="card-body">
            <div class="row no-gutters align-items-center">
              <div class="col mr-2">
                <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Registered Account</div>
                <div class="h6 mb-0 font-weight-bold text-gray-800">
                  <?php 
                    $query = "SELECT COUNT(*) FROM users WHERE TYPE_ID=2";
                    $result = mysqli_query($db, $query) or die(mysqli_error($db));
                    while ($row = mysqli_fetch_array($result)) {
                      echo "$row[0]";
                    }
                  ?> Record(s)
                </div>
              </div>
              <div class="col-auto">
                <i class="fas fa-user fa-2x text-gray-300"></i>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="carousel" style="
        position: relative;
        width: 100%;
        max-width: 600px;
        margin: auto;
        overflow: hidden;
    ">
        <div class="carousel-images" style="
            display: flex;
            transition: transform 0.5s ease;
        ">
            <?php foreach ($images as $image): ?>
                <img src="<?php echo $image; ?>" alt="Carousel Image" style="
                    width: 100%;
                    height: auto;
                ">
            <?php endforeach; ?>
        </div>
        <a class="prev" onclick="plusSlides(-1)" style="
            position: absolute;
            top: 50%;
            width: auto;
            padding: 16px;
            margin-top: -22px;
            color: white;
            font-weight: bold;
            font-size: 18px;
            background-color: rgba(0,0,0,0.5);
            cursor: pointer;
            border: none;
            border-radius: 3px;
            left: 0;
        ">&#10094;</a>
        <a class="next" onclick="plusSlides(1)" style="
            position: absolute;
            top: 50%;
            width: auto;
            padding: 16px;
            margin-top: -22px;
            color: white;
            font-weight: bold;
            font-size: 18px;
            background-color: rgba(0,0,0,0.5);
            cursor: pointer;
            border: none;
            border-radius: 3px;
            right: 0;
        ">&#10095;</a>
    </div>

    <script>
        let slideIndex = 0;
        showSlides();

        function showSlides() {
            const slides = document.querySelectorAll('.carousel-images img');
            slides.forEach((slide, index) => {
                slide.style.display = (index === slideIndex) ? 'block' : 'none';
            });
        }

        function plusSlides(n) {
            const slides = document.querySelectorAll('.carousel-images img');
            slideIndex = (slideIndex + n + slides.length) % slides.length;
            showSlides();
        }
    </script>

<?php
include'../includes/footer.php';
?>